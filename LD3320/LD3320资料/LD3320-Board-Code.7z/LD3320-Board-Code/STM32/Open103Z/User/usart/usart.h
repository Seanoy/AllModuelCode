#ifndef __USART_H
#define	__USART_H

#include "stm32f10x.h"
#include <stdio.h>
#include "usart_config.h"


void USART_init(void);

#endif /* __USART_H */
