#ifndef __DELAY_H
#define __DELAY_H 			   


void delay_ms(u32 SYSCLK,u16 ms);
void delay_us(u32 SYSCLK,u32 us);

#endif



