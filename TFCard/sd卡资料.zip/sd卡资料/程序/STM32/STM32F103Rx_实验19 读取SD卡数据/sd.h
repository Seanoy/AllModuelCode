#ifndef __SD_H
#define __SD_H


// ������
#define MMC    0
#define V1     1
#define V2     2
#define V2HC   4	   


#define	SD_CS  GPIOCOUT(12) //��Ƭѡ

extern u8  SD_Type;//SD��������
extern u16 DeviceCode;	//LCD���к�

u32 SD_GetRoot(u32 nummber);
u32 SD_GetLogic0(void);
u8 SD_SendCommand(u8 cmd,u32 arg,u8 crc,u8 reset);
u8 SD_Init(void);
u32 SD_GetCapacity(void);
u8 SD_ReadBlock(u8 *buffer,u32 sector,u16 len);

#endif




