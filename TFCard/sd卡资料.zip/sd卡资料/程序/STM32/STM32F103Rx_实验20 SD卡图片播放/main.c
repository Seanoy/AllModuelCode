/**
  ******************************************************************************
  * @file    USART/Printf/main.c 
  * @author  MCD Application Team
  * @version V3.3.0
  * @date    04/16/2010
  * @brief   Main program body
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "delay.h"
#include <stdio.h>
#include <stdlib.h>

#include "lcd.h"
#include "sd.h"

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
  

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
u8 SD_Buffer[512];//SD�����ݻ�����
//--------------------------------------------------------------------------------------------
void USART1_Init(void)
{
  USART_InitTypeDef USART_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  //ʹ��A�ں͸���AFIOʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
  //ʹ��USART1ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE); 

  //USART1��Tx�ڳ�ʼ��:�������,50MHz
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  //USART1��Rx�ڳ�ʼ��:��������
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  //USART1��������
  USART_InitStructure.USART_BaudRate = 9600;                   //������9600
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;  //����λΪ8λ
  USART_InitStructure.USART_StopBits = USART_StopBits_1;       //ֹͣλΪ1λ
  USART_InitStructure.USART_Parity = USART_Parity_No;          //����żУ��
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //��Ӳ������
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;      //���������
  USART_Init(USART1, &USART_InitStructure);  
  //USART1ʹ��
  USART_Cmd(USART1, ENABLE);
}
//--------------------------------------------------------------------------------------------
int main(void)
{
  u8 i,j,k;
  u16 ii,jj,mm,nn;
  u32 iiii;
  u32 nummber,nummber_bak;

  //��⵱ǰϵͳʱ��SystemCoreClock
  SystemCoreClockUpdate ();

  USART1_Init();

  LCD_GPIOInit();
  LCD_Init();
	
  POINT_COLOR=RED;
  BACK_COLOR=GRAY;

  LCD_Clear(GRAYBLUE);
  delay_ms(SystemCoreClock,200);

  //���SD��,ʧ����2���������
  while(SD_Init()!=0)
  {
    printf("\r\nδ��⵽SD����");
    LCD_Clear(GRAYBLUE);
    delay_ms(SystemCoreClock,1000);
    LCD_ShowString_ASC32(25,80,"RESET CARD FAILD!",1);
    delay_ms(SystemCoreClock,1000);
  }

  if(SD_Type==V1)
    printf("\r\nV1����ʼ���ɹ���\r\n");
  else if(SD_Type==MMC)
    printf("\r\nMMC����ʼ���ɹ���\r\n");
  else if(SD_Type==V2)
    printf("\r\nV2����ʼ���ɹ���\r\n");
  else if(SD_Type==V2HC)
    printf("\r\nV2HC����ʼ���ɹ���\r\n");
  
  LCD_ShowString_ASC32(50,80,"RESET CARD OK!",1);

  delay_ms(SystemCoreClock,100);



  //�߼�0����������������
  nummber=SD_GetLogic0();

  //��Ŀ¼������������
  nummber_bak=nummber+SD_GetRoot(nummber);



  while (1)
  {
	nummber=nummber_bak;

    do //�ӵ�һ�����������л��ͼƬ����
    {	 //������ǿ���ʼ�������ĵ�һ���ļ�
      SD_ReadBlock(SD_Buffer,nummber++,12);

      for(j=0;j<9;j++)
      {
        if(SD_Buffer[j]!=*((const u8 *)("ͼƬ����:")+j))
          break;
	  }
    }while(j<9);
	

    k=atol((const char *)SD_Buffer+9);

    printf("\r\nͼƬ����:%d��",k);   //�Ӵ������ͼƬ��
    
    //��ͼƬ��ת�����ַ��浽�����г�Ϊ�ַ���
    SD_Buffer[0]=(k%100)/10+0x30;
    SD_Buffer[1]=k%10+0x30;
    SD_Buffer[2]='\0';
    
    //��LCD����ʾ
    LCD_Clear(GRAYBLUE);
    LCD_ShowString_ASC32(30,80,"TOTAL ",1);
    LCD_ShowString_ASC32(30+6*16,80,SD_Buffer,1);
    LCD_ShowString_ASC32(30+6*16+2*16,80," PICTURE",1);

    delay_ms(SystemCoreClock,1000);
    delay_ms(SystemCoreClock,1000);

	for(i=0;i<k;i++)
	{
	  while(1)
	  {
	    SD_ReadBlock(SD_Buffer,nummber++,512);

	    for(j=2;j<7;j++)
		{ //BIN�ļ�ͷ�б�
		  const u8 BIN_HEAD[]={0x00,0x00,0xf0,0x00,0x40,0x01,0x01,0x1b};
		  if(SD_Buffer[j]!=BIN_HEAD[j])
		    break;
		}
        if(j==7)
		{  
		  ii=8; //����������������ʼ��ַ
		  break;
		}

	    
		if(SD_Buffer[0]=='B' && SD_Buffer[1]=='M')
		{ //BMP�ļ�ͷ�б�
		  for(j=0;j<12;j++)
		  {
		    const u8 BMP_HEAD[]={0xf0,0x00,0x00,0x00,0x40,0x01,0x00,0x00,0x01,0x00,0x10,0x00};
		    if(SD_Buffer[j+18]!=BMP_HEAD[j])
		      break;
		  }
        }

		if(j==12)
		{  //����������������ʼ��ַ
		  ii=SD_Buffer[10]+(SD_Buffer[11]<<8)+(SD_Buffer[12]<<16)+(SD_Buffer[13]<<24);
		  break;
		}
	  }

	  //д��ͼ������
	  if(ii==8)
      {	//BIN��ʽ����
	    LCD_SetCursor(0x0000,0x0000); //���ù��
		
        LCD_CS_L;                     //LCDƬѡʹ��
        LCD_WriteRegInde(0x22);       //ѡ��RAM����

        for(iiii=0;iiii<76800;iiii++)
        {
	      if(ii>=512)
          {
	        SD_ReadBlock(SD_Buffer,nummber++,512);
	        ii=0;
		  }
		
		  jj=*(((u16 *)SD_Buffer)+ii/2);
		  ii+=2;

		  LCD_WR_DATA(jj);  //дRAM
	    }
        LCD_CS_H;
      }
      else
      {	//BMP��ʽ����
        for(mm=0;mm<320;mm++)
        {
	      //���þ��Ե�ַ
		  if(DeviceCode==0X8989)
          {
            LCD_WriteReg(0X4E,0);
            LCD_WriteReg(0X4F,319-mm);
          }
          else
          {
            LCD_WriteReg(0x20,0);
            LCD_WriteReg(0x21,319-mm);
          }						    

	      LCD_CS_L;                     //LCDƬѡʹ��
	      LCD_WriteRegInde(0x22);       //ѡ��RAM����

		  for(nn=0;nn<240;nn++)
          {
	        if(ii>=512)
            {
	          SD_ReadBlock(SD_Buffer,nummber++,512);
	          ii=0;
		    }
	    
		    jj=*(((u16 *)SD_Buffer)+ii/2);
			jj=((jj<<1)&0xffc0)+(SD_Buffer[ii]&0x1f);
			ii+=2;

		    LCD_WR_DATA(jj);  //дRAM
	      }
          LCD_CS_H;
	    }
	  }
     
	  for(ii=0;ii<10;ii++)
	    delay_ms(SystemCoreClock,1000);
	}
  }
}

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  USART_SendData(USART1, (uint8_t) ch); /*����һ���ַ�����*/ 

  /* Loop until the end of transmission */
  while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET)/*�ȴ��������*/
  {
  
  }
  return ch;
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
