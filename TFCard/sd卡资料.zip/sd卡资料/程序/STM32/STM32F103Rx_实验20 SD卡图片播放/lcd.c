#include "stm32f10x.h"
#include "lcd.h"
#include "font12.h" 
#include "font16.h" 
#include "font24.h" 
#include "font32.h" 
#include "delay.h"	 

	   
					 
//--------------------------------------------------------------------------------------------

u16 POINT_COLOR=0x0000; //������ɫ
u16 BACK_COLOR=0xFFFF;  //������ɫ
u16 DeviceCode;	 		//LCD ID

//--------------------------------------------------------------------------------------------
//ȫ������
u16 global_xx=0;
u16 global_yy=0;

//--------------------------------------------------------------------------------------------
//LCD�˿ڳ�ʼ��
void LCD_GPIOInit(void)
{ 
  GPIO_InitTypeDef GPIO_InitStructure;		//����GPIO�ṹ����

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE); //ʹ��AFIOʱ��(��һ����������)
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE); //����SW-DP(�ر������Կ���IO��)

  RCC_APB2PeriphClockCmd(LCD_BL_RCC, ENABLE);//ʹ��LCD_BL���ڶ˿�ʱ��
  RCC_APB2PeriphClockCmd(LCD_CS_RCC, ENABLE);//ʹ��LCD_CS���ڶ˿�ʱ��
  RCC_APB2PeriphClockCmd(LCD_RS_RCC, ENABLE);//ʹ��LCD_LCD_RS���ڶ˿�ʱ��
  RCC_APB2PeriphClockCmd(LCD_WR_RCC, ENABLE);//ʹ��LCD_WR���ڶ˿�ʱ��
  RCC_APB2PeriphClockCmd(LCD_RD_RCC, ENABLE);//ʹ��LCD_RD���ڶ˿�ʱ��

  //LCD_BL�˿ڳ�ʼ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
  GPIO_InitStructure.GPIO_Pin = LCD_BL_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LCD_BL_PORT, &GPIO_InitStructure);
  GPIO_SetBits(LCD_BL_PORT,LCD_BL_PIN); //LCD_BL����ߵ�ƽ

  //LCD_CS�˿ڳ�ʼ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
  GPIO_InitStructure.GPIO_Pin = LCD_CS_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LCD_CS_PORT, &GPIO_InitStructure);
  GPIO_SetBits(LCD_CS_PORT,LCD_CS_PIN); //LCD_CS����ߵ�ƽ

  //LCD_RS�˿ڳ�ʼ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
  GPIO_InitStructure.GPIO_Pin = LCD_RS_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LCD_RS_PORT, &GPIO_InitStructure);
  GPIO_SetBits(LCD_RS_PORT,LCD_RS_PIN); //LCD_RS����ߵ�ƽ

  //LCD_WR�˿ڳ�ʼ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
  GPIO_InitStructure.GPIO_Pin = LCD_WR_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LCD_WR_PORT, &GPIO_InitStructure);
  GPIO_SetBits(LCD_WR_PORT,LCD_WR_PIN); //LCD_WR����ߵ�ƽ

  //LCD_RD�˿ڳ�ʼ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
  GPIO_InitStructure.GPIO_Pin = LCD_RD_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LCD_RD_PORT, &GPIO_InitStructure);
  GPIO_SetBits(LCD_RD_PORT,LCD_RD_PIN); //LCD_RD����ߵ�ƽ

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);//ʹ�����ݶ˿�ʱ��

  //���ݶ˿ڳ�ʼ��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}



//--------------------------------------------------------------------------------------------
//LCD��ʼ��
void LCD_Init(void)
{ 
	  					 
  delay_ms(SystemCoreClock,50);
  LCD_WriteReg(0x0000,0x0001);
  delay_ms(SystemCoreClock,50);
  DeviceCode = LCD_ReadReg(0x0000);   
  printf("\r\n\r\nLCD ID:%x",DeviceCode); //����LCD ID  
	
  if(DeviceCode==0x9325||DeviceCode==0x9328)
  {
    LCD_WriteReg(0x00e7,0x0010);      
    LCD_WriteReg(0x0000,0x0001); //���ڲ�ʱ��
    LCD_WriteReg(0x0001,0x0100);     
    LCD_WriteReg(0x0002,0x0700); //����Դ                    
    LCD_WriteReg(0x0003,(1<<12)|(3<<4)|(0<<3) ); //��ʾģʽ
    LCD_WriteReg(0x0004,0x0000);                                   
    LCD_WriteReg(0x0008,0x0207);	           
    LCD_WriteReg(0x0009,0x0000);         
    LCD_WriteReg(0x000a,0x0000);//��ʾ����
    LCD_WriteReg(0x000c,0x0001);//��ʾ����
    LCD_WriteReg(0x000d,0x0000);
    LCD_WriteReg(0x000f,0x0000);
		//��Դ����
    LCD_WriteReg(0x0010,0x0000);   
    LCD_WriteReg(0x0011,0x0007);
    LCD_WriteReg(0x0012,0x0000);                                                                 
    LCD_WriteReg(0x0013,0x0000);                 
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0010,0x1590);   
    LCD_WriteReg(0x0011,0x0227);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0012,0x009c);                  
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0013,0x1900);   
    LCD_WriteReg(0x0029,0x0023);
    LCD_WriteReg(0x002b,0x000e);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0020,0x0000);                                                            
    LCD_WriteReg(0x0021,0x013f);           
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0030,0x0007); 
    LCD_WriteReg(0x0031,0x0707);   
    LCD_WriteReg(0x0032,0x0006);
    LCD_WriteReg(0x0035,0x0704);
    LCD_WriteReg(0x0036,0x1f04); 
    LCD_WriteReg(0x0037,0x0004);
    LCD_WriteReg(0x0038,0x0000);        
    LCD_WriteReg(0x0039,0x0706);     
    LCD_WriteReg(0x003c,0x0701);
    LCD_WriteReg(0x003d,0x000f);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0050,0x0000);
    LCD_WriteReg(0x0051,0x00ef);
    LCD_WriteReg(0x0052,0x0000);
    LCD_WriteReg(0x0053,0x013f);
    
    LCD_WriteReg(0x0060,0xa700);        
    LCD_WriteReg(0x0061,0x0001); 
    LCD_WriteReg(0x006a,0x0000);
    LCD_WriteReg(0x0080,0x0000);
    LCD_WriteReg(0x0081,0x0000);
    LCD_WriteReg(0x0082,0x0000);
    LCD_WriteReg(0x0083,0x0000);
    LCD_WriteReg(0x0084,0x0000);
    LCD_WriteReg(0x0085,0x0000);
  
    LCD_WriteReg(0x0090,0x0010);     
    LCD_WriteReg(0x0092,0x0000);  
    LCD_WriteReg(0x0093,0x0003);
    LCD_WriteReg(0x0095,0x0110);
    LCD_WriteReg(0x0097,0x0000);        
    LCD_WriteReg(0x0098,0x0000);  
    LCD_WriteReg(0x0007,0x0133);
       
    LCD_WriteReg(0x0020,0x0000); //����ַ
  }
  else if(DeviceCode==0x9320||DeviceCode==0x9300)
  {
    LCD_WriteReg(0x00,0x0000);
    LCD_WriteReg(0x01,0x0100);
    LCD_WriteReg(0x02,0x0700);
    LCD_WriteReg(0x03,0x1030);
   
    LCD_WriteReg(0x04,0x0000);
    LCD_WriteReg(0x08,0x0202);
    LCD_WriteReg(0x09,0x0000);
    LCD_WriteReg(0x0a,0x0000);
    LCD_WriteReg(0x0c,(1<<0));
    LCD_WriteReg(0x0d,0x0000);
    LCD_WriteReg(0x0f,0x0000);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x07,0x0101);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x10,(1<<12)|(0<<8)|(1<<7)|(1<<6)|(0<<4));
    LCD_WriteReg(0x11,0x0007);
    LCD_WriteReg(0x12,(1<<8)|(1<<4)|(0<<0));
    LCD_WriteReg(0x13,0x0b00);
    LCD_WriteReg(0x29,0x0000);
    
    LCD_WriteReg(0x2b,(1<<14)|(1<<4));	    
    LCD_WriteReg(0x50,0);
    LCD_WriteReg(0x51,239);
    LCD_WriteReg(0x52,0);
    LCD_WriteReg(0x53,319);
    
    LCD_WriteReg(0x60,0x2700);
    LCD_WriteReg(0x61,0x0001);
    LCD_WriteReg(0x6a,0x0000);
    
    LCD_WriteReg(0x80,0x0000);
    LCD_WriteReg(0x81,0x0000);
    LCD_WriteReg(0x82,0x0000);
    LCD_WriteReg(0x83,0x0000);
    LCD_WriteReg(0x84,0x0000);
    LCD_WriteReg(0x85,0x0000);
   
    LCD_WriteReg(0x90,(0<<7)|(16<<0));
    LCD_WriteReg(0x92,0x0000);
    LCD_WriteReg(0x93,0x0001);
    LCD_WriteReg(0x95,0x0110);
    LCD_WriteReg(0x97,(0<<8));
    LCD_WriteReg(0x98,0x0000);
    LCD_WriteReg(0x07,0x0173);
  }
  else if(DeviceCode==0x1505 || DeviceCode == 0x0505 )
  {
    LCD_WriteReg(0x0007,0x0000);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0012,0x011C);
    LCD_WriteReg(0x00A4,0x0001);
    LCD_WriteReg(0x0008,0x000F);
    LCD_WriteReg(0x000A,0x0008);
    LCD_WriteReg(0x000D,0x0008);	    
  	//٤��У��
    LCD_WriteReg(0x0030,0x0707);
    LCD_WriteReg(0x0031,0x0007);
    LCD_WriteReg(0x0032,0x0603); 
    LCD_WriteReg(0x0033,0x0700); 
    LCD_WriteReg(0x0034,0x0202); 
    LCD_WriteReg(0x0035,0x0002);
    LCD_WriteReg(0x0036,0x1F0F);
    LCD_WriteReg(0x0037,0x0707);
    LCD_WriteReg(0x0038,0x0000); 
    LCD_WriteReg(0x0039,0x0000); 
    LCD_WriteReg(0x003A,0x0707); 
    LCD_WriteReg(0x003B,0x0000);
    LCD_WriteReg(0x003C,0x0007);
    LCD_WriteReg(0x003D,0x0000);
    delay_ms(SystemCoreClock,50);
    LCD_WriteReg(0x0007,0x0001);
    LCD_WriteReg(0x0017,0x0001);//����Դ
    delay_ms(SystemCoreClock,50);
  	//��Դ����
    LCD_WriteReg(0x0010,0x17A0); 
    LCD_WriteReg(0x0011,0x0217);
    LCD_WriteReg(0x0012,0x011E);
    LCD_WriteReg(0x0013,0x0F00);
    LCD_WriteReg(0x002A,0x0000);  
    LCD_WriteReg(0x0029,0x000A);
    LCD_WriteReg(0x0012,0x013E);
    
    LCD_WriteReg(0x0050,0x0000);
    LCD_WriteReg(0x0051,0x00EF); 
    LCD_WriteReg(0x0052,0x0000); 
    LCD_WriteReg(0x0053,0x013F); 
    
    LCD_WriteReg(0x0060,0x2700); 
    LCD_WriteReg(0x0061,0x0001); 
    LCD_WriteReg(0x006A,0x0000); 
    LCD_WriteReg(0x0080,0x0000); 
    
    LCD_WriteReg(0x0081,0x0000); 
    LCD_WriteReg(0x0082,0x0000); 
    LCD_WriteReg(0x0083,0x0000); 
    LCD_WriteReg(0x0084,0x0000); 
    LCD_WriteReg(0x0085,0x0000); 
  	
    LCD_WriteReg(0x0090,0x0013);
    LCD_WriteReg(0x0092,0x0300); 
    LCD_WriteReg(0x0093,0x0005); 
    LCD_WriteReg(0x0095,0x0000); 
    LCD_WriteReg(0x0097,0x0000); 
    LCD_WriteReg(0x0098,0x0000); 
  
    LCD_WriteReg(0x0001,0x0100); 
    LCD_WriteReg(0x0002,0x0700); 
    LCD_WriteReg(0x0003,0x1030); 
    LCD_WriteReg(0x0004,0x0000); 
    LCD_WriteReg(0x000C,0x0000); 
    LCD_WriteReg(0x000F,0x0000); 
    LCD_WriteReg(0x0020,0x0000); 
    LCD_WriteReg(0x0021,0x0000); 
    LCD_WriteReg(0x0007,0x0021); 
    delay_ms(SystemCoreClock,20);
    LCD_WriteReg(0x0007,0x0061); 
    delay_ms(SystemCoreClock,20);
    LCD_WriteReg(0x0007,0x0173); 
    delay_ms(SystemCoreClock,20);
  }
  else if(DeviceCode==0xB505)
  {
    LCD_WriteReg(0x0000,0x0000);
    LCD_WriteReg(0x0000,0x0000);
    LCD_WriteReg(0x0000,0x0000);
    LCD_WriteReg(0x0000,0x0000);
    
    LCD_WriteReg(0x00a4,0x0001);
    delay_ms(SystemCoreClock,20);
    LCD_WriteReg(0x0060,0x2700);
    LCD_WriteReg(0x0008,0x0202);
    
    LCD_WriteReg(0x0030,0x0214);
    LCD_WriteReg(0x0031,0x3715);
    LCD_WriteReg(0x0032,0x0604);
    LCD_WriteReg(0x0033,0x0e16);
    LCD_WriteReg(0x0034,0x2211);
    LCD_WriteReg(0x0035,0x1500);
    LCD_WriteReg(0x0036,0x8507);
    LCD_WriteReg(0x0037,0x1407);
    LCD_WriteReg(0x0038,0x1403);
    LCD_WriteReg(0x0039,0x0020);
    
    LCD_WriteReg(0x0090,0x001a);
    LCD_WriteReg(0x0010,0x0000);
    LCD_WriteReg(0x0011,0x0007);
    LCD_WriteReg(0x0012,0x0000);
    LCD_WriteReg(0x0013,0x0000);
    delay_ms(SystemCoreClock,20);
    
    LCD_WriteReg(0x0010,0x0730);
    LCD_WriteReg(0x0011,0x0137);
    delay_ms(SystemCoreClock,20);
    
    LCD_WriteReg(0x0012,0x01b8);
    delay_ms(SystemCoreClock,20);
    
    LCD_WriteReg(0x0013,0x0f00);
    LCD_WriteReg(0x002a,0x0080);
    LCD_WriteReg(0x0029,0x0048);
    delay_ms(SystemCoreClock,20);
    
    LCD_WriteReg(0x0001,0x0100);
    LCD_WriteReg(0x0002,0x0700);
    LCD_WriteReg(0x0003,0x1230);
    LCD_WriteReg(0x0008,0x0202);
    LCD_WriteReg(0x000a,0x0000);
    LCD_WriteReg(0x000c,0x0000);
    LCD_WriteReg(0x000d,0x0000);
    LCD_WriteReg(0x000e,0x0030);
    LCD_WriteReg(0x0050,0x0000);
    LCD_WriteReg(0x0051,0x00ef);
    LCD_WriteReg(0x0052,0x0000);
    LCD_WriteReg(0x0053,0x013f);
    LCD_WriteReg(0x0060,0x2700);
    LCD_WriteReg(0x0061,0x0001);
    LCD_WriteReg(0x006a,0x0000);
    
    LCD_WriteReg(0x0090,0X0011);
    LCD_WriteReg(0x0092,0x0600);
    LCD_WriteReg(0x0093,0x0402);
    LCD_WriteReg(0x0094,0x0002);
    delay_ms(SystemCoreClock,20);
    
    LCD_WriteReg(0x0007,0x0001);
    delay_ms(SystemCoreClock,20);
    LCD_WriteReg(0x0007,0x0061);
    LCD_WriteReg(0x0007,0x0173);
    
    LCD_WriteReg(0x0020,0x0000);
    LCD_WriteReg(0x0021,0x0000);	  
    LCD_WriteReg(0x00,0x22);  
  }
  else if(DeviceCode==0x8989)
  {	   
    LCD_WriteReg(0x0000,0x0001);//�򿪾���
    LCD_WriteReg(0x0003,0xA8A4);//0xA8A4
    LCD_WriteReg(0x000C,0x0000);    
    LCD_WriteReg(0x000D,0x080C);   
    LCD_WriteReg(0x000E,0x2B00);    
    LCD_WriteReg(0x001E,0x00B0);    
    LCD_WriteReg(0x0001,0x2B3F);//�����������320*240  0x6B3F
    LCD_WriteReg(0x0002,0x0600);
    LCD_WriteReg(0x0010,0x0000);  
    LCD_WriteReg(0x0011,0x6070); //�������ݸ�ʽ 16λɫ	���� 0x6058
    LCD_WriteReg(0x0005,0x0000);  
    LCD_WriteReg(0x0006,0x0000);  
    LCD_WriteReg(0x0016,0xEF1C);  
    LCD_WriteReg(0x0017,0x0003);  
    LCD_WriteReg(0x0007,0x0233);
    LCD_WriteReg(0x000B,0x0000);  
    LCD_WriteReg(0x000F,0x0000); //ɨ�迪ʼ��ַ
    LCD_WriteReg(0x0041,0x0000);  
    LCD_WriteReg(0x0042,0x0000);  
    LCD_WriteReg(0x0048,0x0000);  
    LCD_WriteReg(0x0049,0x013F);  
    LCD_WriteReg(0x004A,0x0000);  
    LCD_WriteReg(0x004B,0x0000);  
    LCD_WriteReg(0x0044,0xEF00);  
    LCD_WriteReg(0x0045,0x0000);  
    LCD_WriteReg(0x0046,0x013F);  
    LCD_WriteReg(0x0030,0x0707);  
    LCD_WriteReg(0x0031,0x0204);  
    LCD_WriteReg(0x0032,0x0204);  
    LCD_WriteReg(0x0033,0x0502);  
    LCD_WriteReg(0x0034,0x0507);  
    LCD_WriteReg(0x0035,0x0204);  
    LCD_WriteReg(0x0036,0x0204);  
    LCD_WriteReg(0x0037,0x0502);  
    LCD_WriteReg(0x003A,0x0302);  
    LCD_WriteReg(0x003B,0x0302);  
    LCD_WriteReg(0x0023,0x0000);  
    LCD_WriteReg(0x0024,0x0000);  
    LCD_WriteReg(0x0025,0x8000);  
    LCD_WriteReg(0x004f,0);        //����ַ0
    LCD_WriteReg(0x004e,0);        //����ַ0
  }
  else if(DeviceCode==0x4531)
  {
    LCD_WriteReg(0X00,0X0001);   
    delay_ms(SystemCoreClock,10);
    LCD_WriteReg(0X10,0X1628);   
    LCD_WriteReg(0X12,0X000e);
    LCD_WriteReg(0X13,0X0A39);   
    delay_ms(SystemCoreClock,10);
    LCD_WriteReg(0X11,0X0040);   
    LCD_WriteReg(0X15,0X0050);   
    delay_ms(SystemCoreClock,10);
    LCD_WriteReg(0X12,0X001e);
    delay_ms(SystemCoreClock,10);
    LCD_WriteReg(0X10,0X1620);   
    LCD_WriteReg(0X13,0X2A39);   
    delay_ms(SystemCoreClock,10);
    LCD_WriteReg(0X01,0X0100);   
    LCD_WriteReg(0X02,0X0300);   
    LCD_WriteReg(0X03,0X1030);
    LCD_WriteReg(0X08,0X0202);   
    LCD_WriteReg(0X0A,0X0008);   
    LCD_WriteReg(0X30,0X0000);   
    LCD_WriteReg(0X31,0X0402);   
    LCD_WriteReg(0X32,0X0106);   
    LCD_WriteReg(0X33,0X0503);   
    LCD_WriteReg(0X34,0X0104);   
    LCD_WriteReg(0X35,0X0301);   
    LCD_WriteReg(0X36,0X0707);   
    LCD_WriteReg(0X37,0X0305);   
    LCD_WriteReg(0X38,0X0208);   
    LCD_WriteReg(0X39,0X0F0B);   
    LCD_WriteReg(0X41,0X0002);   
    LCD_WriteReg(0X60,0X2700);   
    LCD_WriteReg(0X61,0X0001);   
    LCD_WriteReg(0X90,0X0210);   
    LCD_WriteReg(0X92,0X010A);   
    LCD_WriteReg(0X93,0X0004);   
    LCD_WriteReg(0XA0,0X0100);   
    LCD_WriteReg(0X07,0X0001);   
    LCD_WriteReg(0X07,0X0021);   
    LCD_WriteReg(0X07,0X0023);   
    LCD_WriteReg(0X07,0X0033);   
    LCD_WriteReg(0X07,0X0133);   
    LCD_WriteReg(0XA0,0X0000); 
  }			 
  LCD_BL_H;  //��������
//  LCD_BL_L;  //��������
  LCD_Clear(WHITE);	//��ʾ��ɫ
}  		  
//--------------------------------------------------------------------------------------------
//ѡ�Ĵ���(�ͼĴ�����ַ)
void LCD_WriteRegInde(u8 LCD_Reg)
{ 
  LCD_RS_L;
  GPIOB->ODR=LCD_Reg;
  LCD_WR_L;
  LCD_WR_H;
} 	
//--------------------------------------------------------------------------------------------
//д�Ĵ���
void LCD_WriteReg(u8 LCD_Reg, u16 LCD_RegValue)
{	
  LCD_CS_L;
  LCD_WriteRegInde(LCD_Reg);  
  LCD_WR_DATA(LCD_RegValue);	    		 
  LCD_CS_H;
}	   
//--------------------------------------------------------------------------------------------
//���Ĵ���
u16 LCD_ReadReg(u8 LCD_Reg)
{										   
  u16 ii;

  LCD_CS_L;

  LCD_WriteRegInde(LCD_Reg); //�ͼĴ�����ַ
  GPIOB->ODR=0XFFFF;         //���Ԥ��1
  GPIOB->CRL=0X88888888;     //PB�ڵ�8λ��������
  GPIOB->CRH=0X88888888;     //PB�ڸ�8λ��������

  LCD_RS_H;
  LCD_RD_L;					   
  delay_us(SystemCoreClock,1);
  LCD_RD_H;
  ii=GPIOB->IDR;  

  LCD_CS_H;

  GPIOB->ODR=0XFFFF;     //�����1
  GPIOB->CRL=0X33333333; //PB�ڵ�8λ�������
  GPIOB->CRH=0X33333333; //PB�ڸ�8λ�������

  return ii;
}   
//--------------------------------------------------------------------------------------------
//��BGR��ʽת��ΪRGB��ʽ
//93xx����ֵΪBGR,д��ֵRGB
u16 LCD_BGR2RGB(u16 color)
{
  u16  r,g,b,rgb;   

  b=(color>>0)&0x1f;
  g=(color>>5)&0x3f;
  r=(color>>11)&0x1f;	 
  rgb=(b<<11)+(g<<5)+(r<<0);		 

  return(rgb);
}		 
//--------------------------------------------------------------------------------------------
//LCD����ʾ(26��ɫ)
void LCD_DisplayOn(void)
{					   
  LCD_WriteReg(0x7, 0x0173);
}	 
//--------------------------------------------------------------------------------------------
//LCD����ʾ
void LCD_DisplayOff(void)
{	   
  LCD_WriteReg(0x7, 0x0);
}   
//--------------------------------------------------------------------------------------------
//����(ȫ�������ɫ)
void LCD_Clear(u16 color)
{
  u32 index=0;      

  LCD_SetCursor(0x0000,0x0000); //���ù��
  

  LCD_CS_L;
  LCD_WriteRegInde(0x22);       //ѡ��RAM����
  for(index=0;index<76800;index++)
  {
    LCD_WR_DATA(color);  //дRAM
  }
  LCD_CS_H;
}  
//--------------------------------------------------------------------------------------------
//���ù��λ��
void LCD_SetCursor(u16 Xpos, u16 Ypos)
{
#if SCREENTURN==0  //����ת0��
  if(DeviceCode==0X8989)
  {
    LCD_WriteReg(0X4E, Xpos);
    LCD_WriteReg(0X4F, Ypos);
  }
  else
  {
    LCD_WriteReg(0x20, Xpos);
    LCD_WriteReg(0x21, Ypos);
  }						    
#elif SCREENTURN==1  //����ת90��
  if(DeviceCode==0X8989)
  {
    LCD_WriteReg(0X4E, 239-Ypos);
    LCD_WriteReg(0X4F, Xpos);
  }
  else
  {
    LCD_WriteReg(0x20, 239-Ypos);
    LCD_WriteReg(0x21, Xpos);
  }							   
#elif SCREENTURN==2  //����ת180��
  if(DeviceCode==0X8989)
  {
    LCD_WriteReg(0X4E, 239-Xpos);
    LCD_WriteReg(0X4F, 319-Ypos);
  }
  else
  {
    LCD_WriteReg(0x20, 239-Xpos);
    LCD_WriteReg(0x21, 319-Ypos);
  }						    
#elif SCREENTURN==3  //����ת270��
  if(DeviceCode==0X8989)
  {
    LCD_WriteReg(0X4E, Ypos);
    LCD_WriteReg(0X4F, 319-Xpos);
  }
  else
  {
    LCD_WriteReg(0x20, Ypos);
    LCD_WriteReg(0x21, 319-Xpos);
  }							   
#endif
}  
//--------------------------------------------------------------------------------------------
//����
void LCD_DrawPoint(u16 x,u16 y)
{
  LCD_SetCursor(x,y);//���ù��λ�� 
	
  LCD_CS_L;
  LCD_WriteRegInde(0x22);
  LCD_WR_DATA(POINT_COLOR); 
  LCD_CS_H;
} 	 
//--------------------------------------------------------------------------------------------
//��ָ�����������ָ����ɫ
//���Ͻ�:(xend,ysta)
//���½�:(xend,yend)
void LCD_Fill(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color)
{          
  u16 ii,jj;

  for(ii=xsta;ii<=xend;ii++)
  {
    for(jj=ysta;jj<=yend;jj++)
	{
      LCD_SetCursor(ii,jj);   //���ù��λ�� 
      LCD_CS_L;
      LCD_WriteRegInde(0x22); //ѡ��RAM����
      LCD_WR_DATA(color);     //дRAM
    }
    LCD_CS_H;
  }
}  
//--------------------------------------------------------------------------------------------
//��ָ�������ɫֵ	 
//����ֵ:�˵����ɫ
u16 LCD_ReadPoint(u16 x,u16 y)
{
  u16 ii;	

  if(x>=X_MAX||y>=Y_MAX)
    return 0;//������ʾ���򷵻�0
  
  LCD_SetCursor(x,y); //���ù��λ��
  
  LCD_CS_L;
  
  LCD_WriteRegInde(0x22);    //ѡ��RAM���� 
  GPIOB->ODR=0XFFFF;         //���Ԥ��1
  GPIOB->CRL=0X88888888;     //PB�ڵ�8λ��������
  GPIOB->CRH=0X88888888;     //PB�ڸ�8λ��������

  LCD_RS_H;
  LCD_RD_L;  //�ն�һ��
  delay_us(SystemCoreClock,1);
  LCD_RD_H;
  delay_us(SystemCoreClock,1);
  LCD_RD_L;					   
  delay_us(SystemCoreClock,1);
  LCD_RD_H;
  ii=GPIOB->IDR;  
  
  LCD_CS_H;

  GPIOB->ODR=0XFFFF;     //�����1
  GPIOB->CRL=0X33333333; //PB�ڵ�8λ�������
  GPIOB->CRH=0X33333333; //PB�ڸ�8λ�������
  
  if(DeviceCode==0X4531||DeviceCode==0X8989||DeviceCode==0XB505)
    return ii; //��ɫֵ��дһ��ֱ�ӷ���
  else 
    return LCD_BGR2RGB(ii); //��ɫֵ��д��һ����ת���󷵻�
}
//--------------------------------------------------------------------------------------------
//����
//x1,y1:�������
//x2,y2:�յ�����  
void LCD_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2)
{
  u16 ii,jj,kk,ll;
  float scale;
  
  if(x1==x2)
  {	//����
  	if(y2>y1)
	  ii=y1,jj=y2;
	else
	  ii=y2,jj=y1;

	for(;ii<=jj;ii++)
	  {LCD_DrawPoint(x1,ii);}
  }
  else if(y1==y2)
  {	//����
  	if(x2>x1)
	  ii=x1,jj=x2;
	else
	  ii=x2,jj=x1;

	for(;ii<=jj;ii++)
	  {LCD_DrawPoint(ii,y1);}
  }
  else
  {	//б��
  	if(x2>x1)
	  ii=x1,jj=x2,kk=y1,scale=(float)(y2-y1)/(x2-x1);
	else
	  ii=x2,jj=x1,kk=y2,scale=(float)(y1-y2)/(x1-x2);

	for(ll=0;ii<=jj;ii++,ll++)
	  {LCD_DrawPoint(ii,kk+ll*scale);}
  }
}    
//--------------------------------------------------------------------------------------------
//������
void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2)
{
  LCD_DrawLine(x1,y1,x2,y1);
  LCD_DrawLine(x1,y1,x1,y2);
  LCD_DrawLine(x1,y2,x2,y2);
  LCD_DrawLine(x2,y1,x2,y2);
}
//--------------------------------------------------------------------------------------------
//��Բ
//(x,y):Բ��,r:�뾶
void Draw_Circle(u16 x,u16 y,u8 r)
{
  s16 a,b;
  s16 di;

  a = 0;
  b = r;	  
  di = 3 - 2*r;
  while(a<=b)
  {
    LCD_DrawPoint(x-b,y-a);
    LCD_DrawPoint(x+b,y-a);
    LCD_DrawPoint(x-a,y+b);
    LCD_DrawPoint(x-b,y-a);
    LCD_DrawPoint(x-a,y-b);
    LCD_DrawPoint(x+b,y+a);
    LCD_DrawPoint(x+a,y-b);
    LCD_DrawPoint(x+a,y+b);
    LCD_DrawPoint(x-b,y+a);
    a++;
	
	//Bresenham�㷨
    if(di<0)
	  di += 4*a + 6;	  
    else
    {
      di += 10 + 4*(a-b);   
      b--;
    } 
    LCD_DrawPoint(x+a,y+b);
  }
} 
//--------------------------------------------------------------------------------------------
//��(x,y)����ʼ��ʾһ��12*6ASC�ַ���
//*p:����ʾ�ַ���:" "--"~"
//mode:͸��(1),����:(0)
void LCD_ShowString_ASC12(u16 x,u16 y,const u8 *p,u8 mode)
{  
  u8 i,j,k,l;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      
  
  while(*p!='\0')
  {       
    l=*p;
    p++;

    if(x>X12H_MAX || y>Y12_MAX)
      return;	//������ʾ��Χ�˳�

    y_tmp=y;
	for(i=0;i<12;i++)
    {
      k=asc1206[l-32][i];
  
      x_tmp=x;
	  for(j=0;j<6;j++)
      {                 
        if(!mode)
        { //͸��
          if(k&0x01)
          {  
		    POINT_COLOR=color_tmp;
            LCD_DrawPoint(x_tmp,y_tmp);	
          }
		}
		else
		{ //����
          if(k&0x01)
	        POINT_COLOR=color_tmp;
          else 
	        POINT_COLOR=BACK_COLOR;
        
	      LCD_DrawPoint(x_tmp,y_tmp);	
        }
        k=k>>1;
		x_tmp+=1;
      }	
      y_tmp+=1;
	}
    x+=6;
  }  
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʾ�ֿ��дӵ�n����ʼ��m��12*12����
//mode:͸��(1),����:(0)
void LCD_ShowChar_CH12(u16 x,u16 y,u8 n,u8 m,u8 mode)
{  
  u8 i,j,k,l,s;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      


  for(;m>0;m--)
  {
    if(x>X12F_MAX || y>Y12_MAX)
      return;	//������ʾ��Χ�˳�
  
    for(i=0;i<2;i++)
    {
      y_tmp=y;
      for(j=0;j<12;j++)
      {
        k=ch1212[(n<<1)+i][j];
        
        if(i==0) //��1��8λ,��2��4λ
          s=8;
        else
  	    s=4;
  
        x_tmp=x;
  	    for(l=0;l<s;l++)
        {                 
          if(!mode)
          { //͸��
            if(k&0x01)
    		{  
    		  POINT_COLOR=color_tmp;
              LCD_DrawPoint(x_tmp,y_tmp);	
            }
    	  }
          else
          { //����
            if(k&0x01)
    	      POINT_COLOR=color_tmp;
            else 
    	      POINT_COLOR=BACK_COLOR;
            
    	    LCD_DrawPoint(x_tmp,y_tmp);	
    	  }
          k=k>>1;
    	  x_tmp+=1;
        }
        y_tmp+=1;
      }	
      x+=s;
    }
    n++;
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʼ��ʾһ��16*8ASC�ַ���
//*p:����ʾ�ַ���:" "--"~"
//mode:͸��(1),����:(0)
void LCD_ShowString_ASC16(u16 x,u16 y,const u8 *p,u8 mode)
{  
  u8 i,j,k,l;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      
  
  while(*p!='\0')
  {       
    l=*p;
    p++;

    if(x>X16H_MAX || y>Y16_MAX)
      return;	//������ʾ��Χ�˳�

    y_tmp=y;
	for(i=0;i<16;i++)
    {
      k=asc1608[l-32][i];
  
      x_tmp=x;
	  for(j=0;j<8;j++)
      {                 
        if(!mode)
        { //͸��
          if(k&0x01)
          {  
		    POINT_COLOR=color_tmp;
            LCD_DrawPoint(x_tmp,y_tmp);	
          }
		}
		else
		{ //����
          if(k&0x01)
	        POINT_COLOR=color_tmp;
          else 
	        POINT_COLOR=BACK_COLOR;
        
	      LCD_DrawPoint(x_tmp,y_tmp);	
        }
        k=k>>1;
		x_tmp+=1;
      }	
      y_tmp+=1;
	}
    x+=8;
  }  
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʾ�ֿ��дӵ�n����ʼ��m��16*16����
//mode:͸��(1),����:(0)
void LCD_ShowChar_CH16(u16 x,u16 y,u8 n,u8 m,u8 mode)
{  
  u8 i,j,k,l;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      

  for(;m>0;m--)
  {
    if(x>X16F_MAX || y>Y16_MAX)
      return;	//������ʾ��Χ�˳�

    for(i=0;i<2;i++)
    {
      y_tmp=y;
      for(j=0;j<16;j++)
      {
        k=ch1616[(n<<1)+i][j];
      
        x_tmp=x;
        for(l=0;l<8;l++)
        {                 
          if(!mode)
          { //͸��
            if(k&0x01)
		    {  
		      POINT_COLOR=color_tmp;
              LCD_DrawPoint(x_tmp,y_tmp);	
            }
		  }
          else
          { //����
            if(k&0x01)
	          POINT_COLOR=color_tmp;
            else 
	          POINT_COLOR=BACK_COLOR;
        
	        LCD_DrawPoint(x_tmp,y_tmp);	
	      }
          k=k>>1;
		  x_tmp+=1;
        }
        y_tmp+=1;
      }	
      x+=8;
    }
    n++;
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʼ��ʾһ��24*12ASC�ַ���
//*p:����ʾ�ַ���:" "--"~"
//mode:͸��(1),����:(0)
void LCD_ShowString_ASC24(u16 x,u16 y,const u8 *p,u8 mode)
{  
  u8 i,j,k,l,m,n;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      
  
  while(*p!='\0')
  {       
    l=*p;
    p++;

    if(x>X24H_MAX || y>Y24_MAX)
      return;	//������ʾ��Χ�˳�

    for(i=0;i<2;i++)
    {
      y_tmp=y;
      for(j=0;j<24;j++)
      {
        k=asc2412[((l-32)<<1)+i][j];
      
        if(i==0) //��1��8λ,��2��4λ
          m=8;
        else
	      m=4;

        x_tmp=x;
	    for(n=0;n<m;n++)
        {                 
          if(!mode)
          { //͸��
            if(k&0x01)
		    {  
		      POINT_COLOR=color_tmp;
              LCD_DrawPoint(x_tmp,y_tmp);	
            }
		  }
          else
          { //����
            if(k&0x01)
	          POINT_COLOR=color_tmp;
            else 
	          POINT_COLOR=BACK_COLOR;
        
	        LCD_DrawPoint(x_tmp,y_tmp);	
	      }
          k=k>>1;
		  x_tmp+=1;
        }
        y_tmp+=1;
      }	
      x+=m;
    }
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʾ�ֿ��дӵ�n����ʼ��m��24*24����
//mode:͸��(1),����:(0)
void LCD_ShowChar_CH24(u16 x,u16 y,u8 n,u8 m,u8 mode)
{  
  u8 i,j,k,l;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      


  for(;m>0;m--)
  {
    if(x>X24F_MAX || y>Y24_MAX)
      return;	//������ʾ��Χ�˳�

    for(i=0;i<3;i++)
    {
      y_tmp=y;
      for(j=0;j<24;j++)
      {
        k=ch2424[n*3+i][j];
      
        x_tmp=x;
	    for(l=0;l<8;l++)
        {                 
          if(!mode)
          { //͸��
            if(k&0x01)
		    {  
		      POINT_COLOR=color_tmp;
              LCD_DrawPoint(x_tmp,y_tmp);	
            }
		  }
          else
          { //����
            if(k&0x01)
	          POINT_COLOR=color_tmp;
            else 
	          POINT_COLOR=BACK_COLOR;
        
	        LCD_DrawPoint(x_tmp,y_tmp);	
	      }
          k=k>>1;
		  x_tmp+=1;
        }
        y_tmp+=1;
      }	
      x+=8;
    }
    n++;
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʼ��ʾһ��32*16ASC�ַ���
//*p:����ʾ�ַ���:" "--"~"
//mode:͸��(1),����:(0)
void LCD_ShowString_ASC32(u16 x,u16 y,const u8 *p,u8 mode)
{  
  u8 i,j,k,l,m;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      
  
  while(*p!='\0')
  {       
    l=*p;
    p++;

    if(x>X32H_MAX || y>Y32_MAX)
      return;	//������ʾ��Χ�˳�

    for(i=0;i<2;i++)
    {
      y_tmp=y;
      for(j=0;j<32;j++)
      {
        k=asc3216[((l-32)<<1)+i][j];
      
        x_tmp=x;
	    for(m=0;m<8;m++)
        {                 
          if(!mode)
          { //͸��
            if(k&0x01)
		    {  
		      POINT_COLOR=color_tmp;
              LCD_DrawPoint(x_tmp,y_tmp);	
            }
		  }
          else
          { //����
            if(k&0x01)
	          POINT_COLOR=color_tmp;
            else 
	          POINT_COLOR=BACK_COLOR;
        
	        LCD_DrawPoint(x_tmp,y_tmp);	
	      }
          k=k>>1;
		  x_tmp+=1;
        }
        y_tmp+=1;
      }	
      x+=8;
    }
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʾ�ֿ��дӵ�n����ʼ��m��32*32����
//mode:͸��(1),����:(0)
void LCD_ShowChar_CH32(u16 x,u16 y,u8 n,u8 m,u8 mode)
{  
  u8 i,j,k,l;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      


  for(;m>0;m--)
  {
    if(x>X32F_MAX || y>Y32_MAX)
      return;	//������ʾ��Χ�˳�

    for(i=0;i<4;i++)
    {
      y_tmp=y;
      for(j=0;j<32;j++)
      {
        k=ch3232[(n<<2)+i][j];
      
        x_tmp=x;
	    for(l=0;l<8;l++)
        {                 
          if(!mode)
          { //͸��
            if(k&0x01)
		    {  
		      POINT_COLOR=color_tmp;
              LCD_DrawPoint(x_tmp,y_tmp);	
            }
		  }
          else
          { //����
            if(k&0x01)
	          POINT_COLOR=color_tmp;
            else 
	          POINT_COLOR=BACK_COLOR;
        
	        LCD_DrawPoint(x_tmp,y_tmp);	
	      }
          k=k>>1;
		  x_tmp+=1;
        }
        y_tmp+=1;
      }	
      x+=8;
    }
    n++;
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------
//��(x,y)����ʼ��ʾһ��16*8ASC�ַ�
//*p:����ʾ�ַ���:" "--"~"
//mode:͸��(1),����:(0)
void LCD_Show_ASC16(const u8 *p,u8 mode)
{  
  u8 i,j,k,l;
  u16 x_tmp,y_tmp;
  u16 color_tmp=POINT_COLOR;      
  
  l=*p;
  p++;

  if(l<32)
    return;

  y_tmp=global_yy;
  for(i=0;i<16;i++)
  {
    k=asc1608[l-32][i];
  
    x_tmp=global_xx;
    for(j=0;j<8;j++)
    {                 
      if(!mode)
      { //͸��
        if(k&0x01)
        {  
	      POINT_COLOR=color_tmp;
          LCD_DrawPoint(x_tmp,y_tmp);	
        }
	  }
	  else
	  { //����
        if(k&0x01)
          POINT_COLOR=color_tmp;
        else 
          POINT_COLOR=BACK_COLOR;
        
        LCD_DrawPoint(x_tmp,y_tmp);	
      }
      k=k>>1;
	  x_tmp+=1;
    }	
    y_tmp+=1;
  }
  POINT_COLOR=color_tmp;
}   
//--------------------------------------------------------------------------------------------































  






























